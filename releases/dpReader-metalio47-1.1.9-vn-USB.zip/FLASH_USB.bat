@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 flash_usb.py %*
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Install Python 3 from python.org, then retry.
    pause
    exit /b 1
  )
  python flash_usb.py %*
)
set "FLASH_RESULT=%ERRORLEVEL%"
echo.
if not "%FLASH_RESULT%"=="0" echo USB flash failed. Read the error above.
pause
exit /b %FLASH_RESULT%
