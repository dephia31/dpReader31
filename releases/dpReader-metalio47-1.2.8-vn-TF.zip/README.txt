dpReader 1.2.8-vn — Sao chép ứng dụng vào thẻ nhớ và cập nhật qua menu trên thiết bị. Không dùng full.bin cho TF/OTA.
