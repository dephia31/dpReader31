dpReader 1.1.7-vn / Metalio S31
Mac: FLASH_USB.command; Windows: FLASH_USB.bat.
Hai launcher chỉ cập nhật app + otadata, giữ dữ liệu, không backup.
Nạp đầy đủ: dùng ảnh dpReader_metalio47_full.bin tại0x0 qua Web Flasher hoặc esptool.
Bootloader S31 nằm tại0x2000, không dùng phân vùng/bootloader S3.
