dpReader 1.1.9-vn / Metalio 4.7 ESP32-S31
Chép dpReader_metalio47_firmware.bin vào thẻ, mở cập nhật từ thẻ trong Cài đặt. Không dùng cho Pico/ESP32-S3.
