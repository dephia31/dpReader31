Chép dpReader_metalio47_firmware.bin lên thẻ TF, chọn Cài đặt → Cập nhật hệ thống → Cập nhật từ thẻ nhớ.
Không dùng full.bin làm gói TF.
