#!/bin/bash
# 中文：使用兼容S31的本机Python环境。/ English: Use a local Python environment supporting S31.
cd -- "$(dirname -- "$0")" || exit 1
shopt -s nullglob
PYTHON_USB=""
for candidate in "$PWD/.usb-python/bin/python" "$HOME"/.espressif/python_env/*/bin/python; do
  if [ -x "$candidate" ] && "$candidate" -c 'import esptool, serial; assert tuple(int(x) for x in esptool.__version__.split(".")[:2]) >= (5, 6)' >/dev/null 2>&1; then
    PYTHON_USB="$candidate"
    break
  fi
done
if [ -z "$PYTHON_USB" ] && command -v python3 >/dev/null 2>&1; then
  candidate="$(command -v python3)"
  if "$candidate" -c 'import esptool, serial; assert tuple(int(x) for x in esptool.__version__.split(".")[:2]) >= (5, 6)' >/dev/null 2>&1; then
    PYTHON_USB="$candidate"
  fi
fi
if [ -z "$PYTHON_USB" ]; then
  echo 'Python with esptool >=5.6 is missing. In this folder run:'
  echo 'python3 -m venv .usb-python'
  echo '.usb-python/bin/python -m pip install "esptool==5.6.0"'
  read -r -p 'Press Enter to close...'
  exit 1
fi
"$PYTHON_USB" flash_usb.py "$@"
FLASH_RESULT=$?
echo
if [ "$FLASH_RESULT" -ne 0 ]; then
  echo 'USB flash failed. Read the error above.'
  if [ -t 0 ]; then read -r -p 'Press Enter to close...'; fi
  exit "$FLASH_RESULT"
fi
# Close only this launcher's dedicated Terminal window, after the shell exits.
# A shared window with other tabs stays open.
if [ "${TERM_PROGRAM:-}" = "Apple_Terminal" ] && [ -t 0 ]; then
  FLASH_TTY="$(tty)"
  /usr/bin/osascript - "$FLASH_TTY" >/dev/null 2>&1 <<'APPLESCRIPT' &
on run argv
  delay 1
  if application "Terminal" is running then
    tell application "Terminal"
      repeat with flashWindow in windows
        if (count of tabs of flashWindow) is 1 then
          if tty of selected tab of flashWindow is item 1 of argv then
            close flashWindow saving no
            return
          end if
        end if
      end repeat
    end tell
  end if
end run
APPLESCRIPT
fi
exit 0
