#!/usr/bin/env python3
"""USB installer for S31 application updates and clean installs from RC bundles."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import struct
import subprocess
import sys
import tempfile

APP_NAME = 'dpReader_metalio47_firmware.bin'
FLASH_BYTES = 0x1000000
BOOTLOADER_OFFSET = 0x2000
PARTITION_OFFSET = 0x8000
PARTITION_TYPES = {'nvs': (1, 2), 'otadata': (1, 0), 'phy_init': (1, 1),
                   'ota_0': (0, 16), 'ota_1': (0, 17), 'storage': (1, 129), 'coredump': (1, 3)}
EXPECTED = {'nvs': (0x9000, 0x4000), 'otadata': (0xd000, 0x2000),
            'phy_init': (0xf000, 0x1000), 'ota_0': (0x10000, 0x500000),
            'ota_1': (0x510000, 0x500000), 'storage': (0xa10000, 0x5e0000),
            'coredump': (0xff0000, 0x10000)}


LEGACY = dict(EXPECTED)
EXPECTED = {**LEGACY, 'nvs': (0xfb0000, 0x40000), 'storage': (0xa10000, 0x5a0000)}
RC_LAYOUT = {**EXPECTED, 'nvs_old': LEGACY['nvs']}
PARTITION_TYPES['nvs_old'] = (1, 2)


def validate_bundle(folder):
    info = json.loads((folder / 'verification.json').read_text(encoding='utf-8'))
    data = (folder / APP_NAME).read_bytes()
    field = lambda at: data[at:at + 32].split(b'\0')[0].decode('ascii')
    if (info['board'] != 'metalio47' or info['target'] != 'esp32s31' or info['chip_id'] != 32 or
            len(data) < 288 or data[0] != 0xe9 or struct.unpack_from('<H', data, 12)[0] != 32 or
            struct.unpack_from('<I', data, 32)[0] != 0xabcd5432 or
            field(48) != info['version'] or field(80) != 'Kiikoread_Metalio_S31' or
            hashlib.sha256(data).hexdigest() != info['sha256'] or len(data) != info['size']):
        raise ValueError('Wrong board/version or damaged firmware. No flash performed.')
    if {name: tuple(value[2:4]) for name, value in info['partitions'].items()} != EXPECTED:
        raise ValueError('Bundle partition layout is not the approved Metalio S31 layout.')
    checked = set()
    for line in (folder / 'SHA256SUMS.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        if Path(name).name != name or hashlib.sha256((folder / name).read_bytes()).hexdigest() != digest:
            raise ValueError('Bundle checksum mismatch: ' + name)
        checked.add(name)
    if not {APP_NAME, 'storage-empty.bin', 'bootloader.bin', 'partitions.bin'} <= checked:
        raise ValueError('Incomplete USB bundle')
    if (folder / 'storage-empty.bin').stat().st_size != 0x5a0000:
        raise ValueError('Incorrect storage image size')
    validate_partitions((folder / 'partitions.bin').read_bytes().ljust(0x1000, b'\xff'), allow_legacy=False)
    return info


def validate_partitions(data, allow_legacy=True):
    if len(data) != 0x1000:
        raise ValueError('Incomplete partition table. No flash performed.')
    found = {}
    for at in range(0, 0x1000 - 31, 32):
        magic, kind, subtype, offset, size, label, flags = struct.unpack_from('<HBBII16sI', data, at)
        if magic != 0x50aa:
            break
        if label.split(b'\0')[0].decode() in found:
            raise ValueError('Duplicate partition label')
        found[label.split(b'\0')[0].decode()] = (kind, subtype, offset, size, flags)
    trailer = data[len(found) * 32:]
    if trailer[:2] == b'\xeb\xeb':
        if hashlib.md5(data[:len(found)*32]).digest() != trailer[16:32]:
            raise ValueError('Partition-table MD5 mismatch')
        trailer = trailer[32:]
    if trailer != b'\xff' * len(trailer):
        raise ValueError('Unexpected partition-table trailer')
    expected = {name: (*PARTITION_TYPES[name], *shape, 0) for name, shape in EXPECTED.items()}
    if found == expected:
        return 'new'
    legacy = {name: (*PARTITION_TYPES[name], *shape, 0) for name, shape in LEGACY.items()}
    if allow_legacy:
        if data == b'\xff' * 0x1000:
            return 'blank'
        if found == legacy:
            return 'legacy'
        if found == {name: (*PARTITION_TYPES[name], *shape, 0) for name, shape in RC_LAYOUT.items()}:
            return 'rc'
    raise ValueError('Device partition layout differs. No flash performed.')


def validate_port(port):
    if not (re.fullmatch(r'COM[1-9][0-9]*', port, re.I) or
            re.fullmatch(r'/dev/cu\.(?:usbmodem|usbserial)[A-Za-z0-9._-]+', port)):
        raise ValueError('Expected COM5 on Windows or /dev/cu.usbmodem... on macOS.')


def command(port, *args, after='no-reset', before='default-reset'):
    return [sys.executable, '-m', 'esptool', '--chip', 'esp32s31', '--port', port,
            '--baud', '115200', '--no-stub', '--before', before,
            '--after', after, *args]


def full_image(folder, info):
    """Assemble a clean 16 MiB image from a previously validated RC bundle."""
    if 'RC' not in info['version'] or info.get('bootloader_offset') != BOOTLOADER_OFFSET:
        raise ValueError('Full image requires an S31 RC bundle with its matching bootloader.')
    app_offset, app_capacity = EXPECTED['ota_0']
    storage_offset, storage_capacity = EXPECTED['storage']
    bootloader = (folder / 'bootloader.bin').read_bytes()
    if (len(bootloader) < 24 or bootloader[0] != 0xe9 or
            struct.unpack_from('<H', bootloader, 12)[0] != 32):
        raise ValueError('Bootloader is not an ESP32-S31 image.')
    parts = (
        (BOOTLOADER_OFFSET, PARTITION_OFFSET - BOOTLOADER_OFFSET, bootloader),
        (PARTITION_OFFSET, 0x1000, (folder / 'partitions.bin').read_bytes()),
        (app_offset, app_capacity, (folder / APP_NAME).read_bytes()),
        (storage_offset, storage_capacity, (folder / 'storage-empty.bin').read_bytes()),
    )
    image = bytearray(b'\xff' * FLASH_BYTES)
    for offset, capacity, data in parts:
        if len(data) > capacity:
            raise ValueError(f'Image segment at {offset:#x} exceeds its allotted space.')
        image[offset:offset + len(data)] = data
    return image


def write_full_image(port, mac, image):
    identity = subprocess.check_output(command(port, 'flash-id', before='no-reset'),
                                       text=True, stderr=subprocess.STDOUT)
    if not re.search(r'MAC:\s*' + re.escape(mac) + r'\b', identity, re.I):
        raise RuntimeError('Device identity changed. No flash performed.')
    if not re.search(r'^Detected flash size:\s*16MB\s*$', identity, re.M):
        raise RuntimeError('A 16 MB flash chip is required. No flash performed.')
    with tempfile.TemporaryDirectory(prefix='metalio-full-usb-') as tmp:
        path = Path(tmp) / 'dpReader_metalio47_full.bin'
        path.write_bytes(image)
        subprocess.run(command(port, 'write-flash', '--flash-mode', 'dio', '--flash-freq', '80m',
                               '--flash-size', '16MB', '--no-compress', '0x0', str(path),
                               before='no-reset'), check=True)


def main():
    parser = argparse.ArgumentParser(description='Metalio E-ink 4 Plus / S31 USB flash')
    parser.add_argument('--port')
    parser.add_argument('--full-image', action='store_true', help='Write a clean RC image to all 16 MB')
    args = parser.parse_args()
    folder = Path(__file__).resolve().parent
    info = validate_bundle(folder)
    image = full_image(folder, info) if args.full_image else None
    try:
        import esptool
        from serial.tools import list_ports
    except ImportError:
        raise RuntimeError('Install esptool in your Python environment: python -m pip install "esptool==5.6.0"')
    if tuple(int(x) for x in esptool.__version__.split('.')[:2]) < (5, 6):
        raise RuntimeError('S31 requires esptool >=5.6. Run: python -m pip install "esptool==5.6.0"')
    port = args.port
    if not port:
        ports = [p for p in list_ports.comports() if p.vid == 0x303a]
        if not ports:
            raise RuntimeError('No Espressif USB device. Connect S31 in download mode and retry.')
        for index, item in enumerate(ports, 1):
            print(f'{index}: {item.device} - {item.description}')
        if len(ports) == 1 and not args.full_image:
            port = ports[0].device
        else:
            index = int(input('Chọn số cổng USB / Select port number: '))
            if not 1 <= index <= len(ports):
                raise ValueError('Invalid USB port selection.')
            port = ports[index - 1].device
    validate_port(port)
    print(f'Metalio E-ink 4 Plus / ESP32-S31 | {info["version"]} | {port}', flush=True)
    if args.full_image:
        print('CÀI SẠCH 16 MB: đặt lại cài đặt và bộ nhớ trong. Thẻ SD giữ nguyên.', flush=True)
    print('Checking chip and flash size.' if args.full_image else 'Checking chip and partition table.',
          flush=True)
    try:
        identity = subprocess.check_output(
            command(port, '--connect-attempts', '1', 'read-mac', before='no-reset'),
            text=True, stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError:
        print('No response in BOOT mode. Trying automatic reset...', flush=True)
        try:
            identity = subprocess.check_output(command(port, 'read-mac'),
                                               text=True, stderr=subprocess.STDOUT)
        except subprocess.CalledProcessError as error:
            print(error.output, file=sys.stderr)
            raise RuntimeError(
                'Cannot connect. Disconnect Web Flash or any serial monitor, '
                'then hold Power + AI for about 3 seconds, release, and retry.'
            ) from error
    print(identity)
    match = re.search(r'MAC:\s*([0-9a-f:]{17})', identity, re.I)
    if not match:
        raise RuntimeError('Cannot verify device MAC. No flash performed.')
    mac = match[1].lower()
    if image is not None:
        write_full_image(port, mac, image)
    else:
        write_application(port, mac, folder, info)
    # S31 USB Serial/JTAG can remain in ROM after an RTS-only reset. Use the
    # transient watchdog reset after verification.
    print('Verified USB write. Restarting the device into firmware...', flush=True)
    subprocess.run(command(port, 'read-mac', before='no-reset', after='watchdog-reset'), check=True)
    print(f'USB write completed. After reboot, verify the device version is {info["version"]}.')
    print('Boot and screen behavior still require checking on the device.')


def write_application(port, mac, folder, info):
    with tempfile.TemporaryDirectory(prefix='metalio-usb-') as tmp:
        scratch = Path(tmp)
        table = scratch / 'partitions.bin'
        subprocess.run(command(port, 'read-flash', '--flash-size', '16MB', '--no-progress',
                               '0x8000', '0x1000', str(table), before='no-reset'), check=True)
        layout = validate_partitions(table.read_bytes())
        if layout != 'new' and 'RC' in info['version']:
            raise RuntimeError('Local RC requires the matching partition layout. No flash performed; user data preserved.')
        if layout != 'new':
            print('CÀI SẠCH: đang chuẩn bị tạo lại NVS và bộ nhớ trong /flash. Thẻ SD giữ nguyên.', flush=True)

        again = subprocess.check_output(command(port, 'read-mac', before='no-reset'),
                                        text=True, stderr=subprocess.STDOUT)
        if not re.search(r'MAC:\s*' + re.escape(mac) + r'\b', again, re.I):
            raise RuntimeError('Device identity changed. No flash performed.')

        clear = scratch / 'ota-select-ota0.bin'
        clear.write_bytes(b'\xff' * 0x2000)
        writes = ['0x10000', str(folder / APP_NAME), '0xd000', str(clear)]
        if layout != 'new':
            empty_old = scratch / 'erase-legacy.bin'
            empty_new = scratch / 'erase-nvs.bin'
            empty_old.write_bytes(b'\xff' * 0x4000)
            empty_new.write_bytes(b'\xff' * 0x40000)
            writes += ['0x9000', str(empty_old), '0xa10000', str(folder / 'storage-empty.bin'),
                       '0xfb0000', str(empty_new)]
            if layout == 'blank':
                writes += ['0x2000', str(folder / 'bootloader.bin')]
        subprocess.run(command(port, 'write-flash', '--flash-size', '16MB', *writes,
                               before='no-reset'), check=True)
        if layout != 'new':
            subprocess.run(command(port, 'write-flash', '0x8000', str(folder / 'partitions.bin'),
                                   before='no-reset'), check=True)


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as error:
        print(f'ERROR: {error}', file=sys.stderr)
        sys.exit(1)
